package com.marionete.controller;

import com.marionete.dto.UserDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping("/marionete/user")
    public ResponseEntity<UserDTO> getProduct(@RequestHeader(name = "Authorization", required = true) String token) {
        UserDTO user = new UserDTO("John", "Doe", "male", 32);
        return new ResponseEntity<UserDTO>(user, HttpStatus.OK);
    }

}
