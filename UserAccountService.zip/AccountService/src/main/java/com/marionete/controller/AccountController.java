package com.marionete.controller;

import com.marionete.dto.AccountDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {
    @GetMapping("/marionete/account")
    public ResponseEntity<AccountDTO> getProduct(@RequestHeader(name = "Authorization", required = true) String token) {
        AccountDTO account = new AccountDTO();
        account.setAccountNumber("12345-3346-3335-4456");
        return new ResponseEntity<AccountDTO>(account, HttpStatus.OK);
    }
}
