package com.marionete;

public class ExceptionHandler {
}
