package com.marionete.controller;

import com.marionete.dto.UserAccountDTO;
import com.marionete.dto.UserCredVO;
import com.marionete.exception.AccountNotFoundException;
import com.marionete.exception.UserNotFoundException;
import com.marionete.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.concurrent.ExecutionException;

@RestController
public class UserAccountController {

    @Autowired
    UserAccountService userAccountService;

    @PostMapping("/marionete/useraccount/")
    public ResponseEntity<UserAccountDTO> getProduct(@Valid @RequestBody UserCredVO userCredVO) throws ExecutionException, InterruptedException, AccountNotFoundException, UserNotFoundException {
        UserAccountDTO user = userAccountService.buildUserAccount();
        return new ResponseEntity<UserAccountDTO>(user, HttpStatus.OK);
    }

}
