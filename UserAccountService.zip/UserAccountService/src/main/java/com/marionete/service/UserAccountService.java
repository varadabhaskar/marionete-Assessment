package com.marionete.service;

import com.marionete.dto.UserAccountDTO;
import com.marionete.exception.AccountNotFoundException;
import com.marionete.exception.UserNotFoundException;

import java.util.concurrent.ExecutionException;


public interface UserAccountService {
    /**
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public UserAccountDTO buildUserAccount() throws ExecutionException, InterruptedException, AccountNotFoundException, UserNotFoundException;
}
