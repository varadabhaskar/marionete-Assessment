package com.marionete.service;

import com.marionete.dto.UserAccountDTO;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;

public interface UserAccountService {
    public UserAccountDTO buildUserAccount() throws ExecutionException, InterruptedException;
}
