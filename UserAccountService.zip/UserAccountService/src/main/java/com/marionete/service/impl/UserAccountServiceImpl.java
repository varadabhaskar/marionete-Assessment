package com.marionete.service.impl;

import com.marionete.dto.AccountDTO;
import com.marionete.dto.UserAccountDTO;
import com.marionete.dto.UserDTO;
import com.marionete.exception.AccountNotFoundException;
import com.marionete.exception.UserNotFoundException;
import com.marionete.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/***
 * This is class is being used to invoke the rest endpoints of User and Account
 * @author BVarada
 */
@Component
@Qualifier("userAccountService")
public class UserAccountServiceImpl implements UserAccountService {

    @Autowired
    RestTemplate restTemplate;

    @Value("${externalendpoint.userAPIURI}")
    private String userAPIURI1;

    @Value("${externalendpoint.accountAPIURI}")
    private String accountAPIURI1;

    @Value("${authorization.token}")
    String authHeader;

    /** Building the UserAccount object by calling the api endpoints of user and account.
     * Implementing an Async functionality to invoke the end points , will enable to call the services
     * parallelly by spanning the threads.
     *
     * @return UserAccountDTO
     * @throws ExecutionException
     * @throws InterruptedException
     * @throws AccountNotFoundException
     * @throws UserNotFoundException
     */
    @Override
    public UserAccountDTO buildUserAccount() throws ExecutionException, InterruptedException, AccountNotFoundException, UserNotFoundException {
        UserAccountDTO userAccountDTO = new UserAccountDTO();
        CompletableFuture<UserDTO> userDto = getUserInfo(authHeader,userAPIURI1);
        CompletableFuture<AccountDTO> acccDto = getAccountInfo(authHeader,accountAPIURI1);
        userAccountDTO.setUserDTO(userDto.get());
        userAccountDTO.setAccountDTO(acccDto.get());
        return userAccountDTO;
    }

    /** Invoking user api to get the user info details
     * @param authHeader
     * @param uri
     * @return
     * @throws UserNotFoundException
     */
    @Async
    public CompletableFuture<UserDTO> getUserInfo( String authHeader, String uri) throws UserNotFoundException {
        ResponseEntity<UserDTO> response = (ResponseEntity<UserDTO>) getDtoResponseEntity(authHeader, uri,UserDTO.class);
        HttpStatus status = response.getStatusCode();
        if (status != HttpStatus.OK) {
            throw new UserNotFoundException("No User found");
        }
        return CompletableFuture.completedFuture(response.getBody());
    }

    /** Invoking account api to get the account details of the user
     * @param authHeader
     * @param uri
     * @return
     * @throws AccountNotFoundException
     */
    @Async
    public CompletableFuture<AccountDTO> getAccountInfo( String authHeader, String uri) throws AccountNotFoundException {
        ResponseEntity<AccountDTO> response = (ResponseEntity<AccountDTO>) getDtoResponseEntity(authHeader, uri, AccountDTO.class);
        HttpStatus status = response.getStatusCode();
        if (status != HttpStatus.OK) {
            throw new AccountNotFoundException("No Account found");
        }
        return CompletableFuture.completedFuture(response.getBody());
    }


    /**Generic function to call the end point , response object is reponse entity with generic
     * @param authHeader
     * @param uri
     * @param clazz
     * @return
     */
    private ResponseEntity<?> getDtoResponseEntity(String authHeader, String uri,Class<?> clazz) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authHeader);
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<?> response = restTemplate.exchange(uri,HttpMethod.GET,entity,clazz);
        return response;
    }
}
