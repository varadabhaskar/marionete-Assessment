package com.marionete.service.impl;

import com.marionete.dto.AccountDTO;
import com.marionete.dto.UserAccountDTO;
import com.marionete.dto.UserDTO;
import com.marionete.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Qualifier("userAccountService")
public class UserAccountServiceImpl implements UserAccountService {

    @Autowired
    RestTemplate restTemplate;

    @Override
    public UserAccountDTO buildUserAccount() throws ExecutionException, InterruptedException {
        UserAccountDTO userAccountDTO = new UserAccountDTO();
        String authHeader = "token";
        String userAPIURI = "http://localhost:8898/marionete/user";
        String accountAPIURI = "http://localhost:8899/marionete/account";
        CompletableFuture<UserDTO> userDto = getUserInfo(authHeader,userAPIURI);
        CompletableFuture<AccountDTO> acccDto = getAccountInfo(authHeader,accountAPIURI);
        userAccountDTO.setUserDTO(userDto.get());
        userAccountDTO.setAccountDTO(acccDto.get());
        return userAccountDTO;
    }

    @Async
    public CompletableFuture<UserDTO> getUserInfo( String authHeader, String uri) {
        ResponseEntity<UserDTO> response = (ResponseEntity<UserDTO>) getDtoResponseEntity(authHeader, uri,UserDTO.class);
        return CompletableFuture.completedFuture(response.getBody());
    }

    @Async
    public CompletableFuture<AccountDTO> getAccountInfo( String authHeader, String uri) {
        ResponseEntity<AccountDTO> response = (ResponseEntity<AccountDTO>) getDtoResponseEntity(authHeader, uri, AccountDTO.class);
        return CompletableFuture.completedFuture(response.getBody());
    }


    private ResponseEntity<?> getDtoResponseEntity(String authHeader, String uri,Class<?> clazz) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authHeader);
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<?> response = restTemplate.exchange(uri,HttpMethod.GET,entity,clazz);
        return response;
    }
}
