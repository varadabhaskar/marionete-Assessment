package com.marionete.controller;

import com.marionete.dto.UserAccountDTO;
import com.marionete.dto.UserCredVO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class UserAccountControllerTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void userAccountTest() throws Exception {
        UserCredVO credVO = new UserCredVO();
        credVO.setUsername("bla");
        credVO.setPassword("foo");
        ResponseEntity<UserAccountDTO> response = this.restTemplate.postForEntity("http://localhost:" + port + "/marionete/useraccount/",credVO,UserAccountDTO.class);
        Assertions.assertEquals(response.getBody().getUserDTO().getName(),"John");
    }

    @Test
    public void userAccountTestWithOutPassException() throws Exception {
        UserCredVO credVO = new UserCredVO();
        credVO.setUsername("bla");
        ResponseEntity<UserAccountDTO> response = this.restTemplate.postForEntity("http://localhost:" + port + "/marionete/useraccount/",credVO,UserAccountDTO.class);
        Assertions.assertEquals(400,response.getStatusCodeValue());
    }

    @Test
    public void userAccountTestWithOutUserException() throws Exception {
        UserCredVO credVO = new UserCredVO();
        credVO.setPassword("foo");
        ResponseEntity<UserAccountDTO> response = this.restTemplate.postForEntity("http://localhost:" + port + "/marionete/useraccount/",credVO,UserAccountDTO.class);
        Assertions.assertEquals(400,response.getStatusCodeValue());
    }


    @Test
    public void userAccountTestWithOutUserAndPassException() throws Exception {
        UserCredVO credVO = new UserCredVO();
        ResponseEntity<UserAccountDTO> response = this.restTemplate.postForEntity("http://localhost:" + port + "/marionete/useraccount/",credVO,UserAccountDTO.class);
        Assertions.assertEquals(400,response.getStatusCodeValue());
    }





}